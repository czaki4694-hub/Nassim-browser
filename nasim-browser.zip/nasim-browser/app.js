(() => {
const $ = s => document.querySelector(s);
const ENG = {DuckDuckGo:'https://duckduckgo.com/?q=',Google:'https://www.google.com/search?q=',Brave:'https://search.brave.com/search?q=',Bing:'https://www.bing.com/search?q='};
const DEF = [['ويكيبيديا','https://ar.wikipedia.org'],['MDN','https://developer.mozilla.org'],['OpenStreetMap','https://www.openstreetmap.org'],['GitHub','https://github.com']];
const load = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d } catch { return d } };
const save = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)) } catch {} };
let S = load('nasim', {tabs:[{id:1,url:'',h:[''],i:0}], cur:1, bm:DEF, eng:'DuckDuckGo', theme:''});
let seq = Math.max(...S.tabs.map(t => t.id)) + 1;
const cur = () => S.tabs.find(t => t.id === S.cur);
const persist = () => save('nasim', S);
const host = u => { try { return new URL(u).hostname.replace(/^www\./,'') } catch { return u } };
const hue = s => [...s].reduce((a,c) => a + c.charCodeAt(0) * 37, 0) % 360;

function parse(q) {
  q = q.trim(); if (!q) return '';
  if (/^https?:\/\//i.test(q)) return q;
  if (/^[^\s]+\.[a-z]{2,}(\/.*)?$/i.test(q)) return 'https://' + q;
  return ENG[S.eng] + encodeURIComponent(q);
}
function go(url, push = true) {
  const t = cur(); t.url = url;
  if (push) { t.h = t.h.slice(0, t.i + 1).concat(url); t.i = t.h.length - 1; }
  persist(); render(true);
}
function render(reload) {
  const t = cur();
  document.documentElement.dataset.theme = S.theme;
  $('#tabs').innerHTML = '';
  S.tabs.forEach(x => {
    const d = document.createElement('div');
    d.className = 'tab' + (x.id === S.cur ? ' on' : '');
    d.innerHTML = '<span></span><b title="إغلاق">×</b>';
    d.firstChild.textContent = x.url ? host(x.url) : 'تبويب جديد';
    d.onclick = e => { if (e.target.tagName === 'B') close(x.id); else { S.cur = x.id; persist(); render(true); } };
    $('#tabs').append(d);
  });
  const n = document.createElement('button'); n.id = 'new'; n.textContent = '+'; n.title = 'تبويب جديد';
  n.onclick = () => { const id = seq++; S.tabs.push({id,url:'',h:[''],i:0}); S.cur = id; persist(); render(true); };
  $('#tabs').append(n);
  $('#engine').innerHTML = Object.keys(ENG).map(e => `<option${e === S.eng ? ' selected' : ''}>${e}</option>`).join('');
  if (document.activeElement !== $('#addr')) $('#addr').value = t.url;
  $('#star').textContent = S.bm.some(b => b[1] === t.url) ? '★' : '☆';
  $('#star').classList.toggle('on', $('#star').textContent === '★');
  $('#back').disabled = t.i < 1; $('#fwd').disabled = t.i >= t.h.length - 1;
  $('#home').hidden = !!t.url; $('#view').hidden = !t.url; $('#note').hidden = !t.url;
  if (reload) $('#view').src = t.url || 'about:blank';
  if (!t.url) dial();
}
function close(id) {
  S.tabs = S.tabs.filter(t => t.id !== id);
  if (!S.tabs.length) S.tabs = [{id:seq++,url:'',h:[''],i:0}];
  if (!S.tabs.some(t => t.id === S.cur)) S.cur = S.tabs[S.tabs.length - 1].id;
  persist(); render(true);
}
function dial() {
  const box = $('#dial'); box.innerHTML = '';
  S.bm.forEach(([name, url], i) => {
    const a = document.createElement('a'); a.className = 'd'; a.href = url;
    a.innerHTML = `<i style="background:hsl(${hue(host(url))} 60% 48%)"></i><u></u><em title="حذف">×</em>`;
    a.firstChild.textContent = (name[0] || '?').toUpperCase(); a.querySelector('u').textContent = name;
    a.onclick = e => { e.preventDefault(); if (e.target.tagName === 'EM') { S.bm.splice(i, 1); persist(); dial(); } else go(url); };
    box.append(a);
  });
}
$('#form').onsubmit = e => { e.preventDefault(); const u = parse($('#addr').value); if (u) go(u); $('#addr').blur(); };
$('#addr').onfocus = e => e.target.select();
$('#engine').onchange = e => { S.eng = e.target.value; persist(); };
$('#back').onclick = () => { const t = cur(); if (t.i > 0) { t.i--; go(t.h[t.i], false); } };
$('#fwd').onclick = () => { const t = cur(); if (t.i < t.h.length - 1) { t.i++; go(t.h[t.i], false); } };
$('#reload').onclick = () => { const v = $('#view'); if (cur().url) v.src = cur().url; };
$('#star').onclick = () => {
  const t = cur(); if (!t.url) return;
  const i = S.bm.findIndex(b => b[1] === t.url);
  if (i > -1) S.bm.splice(i, 1); else S.bm.push([host(t.url), t.url]);
  persist(); render();
};
const out = () => { const u = cur().url; if (u) window.open(u, '_blank', 'noopener'); };
$('#ext').onclick = out; $('#open').onclick = out;
$('#theme').onclick = () => { S.theme = (S.theme || (matchMedia('(prefers-color-scheme:dark)').matches ? 'dark' : 'light')) === 'dark' ? 'light' : 'dark'; persist(); render(); };
if (!S.theme && matchMedia('(prefers-color-scheme:dark)').matches) S.theme = 'dark';
addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key === 'l') { e.preventDefault(); $('#addr').focus(); } });
if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => {});
render(true);
})();
